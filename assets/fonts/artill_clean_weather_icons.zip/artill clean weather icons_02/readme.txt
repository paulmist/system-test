Thank you for downloading this font!

Also a big thanks to  Adam Whitcroft for his inspiring "Climacons"!
http://dribbble.com/AdamWhitcroft


This font is copyright (c) artill (www.artill.de) 
all rights reserved. Do not distribute without the author's permission.

Use this font for non-commercial use only! If you plan to use it for commercial purposes, contact me before doing so!

Have fun and enjoy!
____________________
artill

lukas[at]artill[dot]de
www.artill.de
www.blog.artill.de

                                                                                          
                                           .--.`                  `::::.                  
                                           -://:`               `-://///:.                
                                           -/::/:`             .::://:////.               
                                           -/:../-            .:::////////-               
                                           -//``:/.          `:/:/:.-/////:`              
                                           ./:` :/-         `-///:`  :////:`              
                                           .::` :/-         -///:`   `////:`              
                                   `       `:/` :/-        .:///.    `////:`              
                                 `-:::`     -/.`//-        :///-`    `////-               
                        `-`     `.``-/:     ./-.//.       .////.     `////-               
                        `/:`    .:/::/.     `/:-/:.       -///:`     .////.               
                        `:/`       ```       :/:/:`      `:///-      :///-                
                         ./-                 `://.       `////`     `///:`                
                         `::... `:/-`        `-//-       .///:`    `://-`                 
                       `-:///:-  -//-        `://:`      .///:    .://-                   
                         `./:`   `:/:`       -////-`     .//:.   `://-                    
                    `-.   `:/-    .//.     `-/:.-//:`    .//:. `-:/:.                     
        ``..` `-.  .:/:`  .///.   `///:-.`.:/:`  .://-.` .///-::::-`                      
      `-:/:/:``:/::///.   .////::::///////::-`    `-////::////::-`                        
     `::.``-/. -:`.//:`  `-/-.-::::::. `````        `-://////-`                           
    `-` `.::/:`-: `///-``:/-                           ```.//`                            
        .:.`:/::.  `.:///:.                                :/:                            
        .::-::-`      ``.`                                 -//.                           
          ```                                              `://.                          
                                                            `:/:`                         
                                                             `:/:`                        
                                                              `-/:`                       
                                                                `.-`                      
                                                                  `-:-.`         ``       
                                                                    `.--:--.  ``          
                                                                                          